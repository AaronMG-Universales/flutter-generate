class UrlProvider {
  static final UrlProvider shared = UrlProvider._();
  UrlProvider._();
}
